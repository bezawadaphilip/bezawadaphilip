
import streamlit as st
st.title('Password Strength Prediction Using ML')


import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer , TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

data=pd.read_csv("password-strength.csv")
data1=data['stength']=data['strength'].map({0:"weak", 1:'medium' , 2:'strong'})

def word(password):
  character=[]
  for i in password:
    character.append(i)
  return password

x=np.array(data['password'])
y=np.array(data['strength'])

tfidf=TfidfVectorizer(tokenizer=word)
x=tfidf.fit_transform(x)

xtrain,xtest,ytrain,ytest=train_test_split(x,y,test_size=0.05 , random_state=42)

from sklearn.ensemble import RandomForestClassifier
model=RandomForestClassifier()
model.fit(xtrain,ytrain)


user=st.text_input('Enter Password')
if st.button('Check Strength'):
   data1=tfidf.transform([user]).toarray()
   output = model.predict(data1)
   st.success(output[0])


    



